package com.stempleRun.db.mapper;

import com.stempleRun.db.dto.Amenity;

public interface AmenityMapper {

	public void insert(Amenity a);
	
}
