package com.stempleRun.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.servlet.http.HttpServletRequest;

import org.slf4j.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.stempleRun.db.dto.Area;
import com.stempleRun.db.dto.Culture;
import com.stempleRun.db.dto.Hint;
import com.stempleRun.db.dto.Question;
import com.stempleRun.db.dto.Story;
import com.stempleRun.db.dto.Story_only;
import com.stempleRun.db.dto.app_story;
import com.stempleRun.db.dto.app_storyStart;
import com.stempleRun.db.service.AreaService;
import com.stempleRun.db.service.CultureService;
import com.stempleRun.db.service.HintService;
import com.stempleRun.db.service.QuestionService;
import com.stempleRun.db.service.StorageService;
import com.stempleRun.db.service.StoryService;
import com.stempleRun.db.service.Story_onlyService;
import com.stempleRun.db.service.app_StoryService;
import com.stempleRun.db.service.app_storyStartService;

@Controller
@RequestMapping("/storymake")
public class StoryMakeController {

	private final Logger logger = LoggerFactory.getLogger(StoryMakeController.class);
	
	@Autowired
	CultureService service;

	@Autowired
	AreaService areaService;

	@Autowired
	StoryService storyService;
	
	@Autowired
	QuestionService questionService;
	
	@Autowired
	Story_onlyService soService;
	
	@Autowired
	HintService hintService;
	
	@Autowired
	app_StoryService appService;
	
	@Autowired
	app_storyStartService appStartService;
	
	String fileName = null;
	
	@Autowired
	StorageService storageService;

	@RequestMapping(value = "/reg")
	public String register(Model model) {

		try {

			model.addAttribute("areaList", areaService.getAreas());

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "/story/storyRegister";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(HttpServletRequest request, RedirectAttributes redirectAttr, Model model) throws Exception {

		model.addAttribute("cultureList", service.getCultures());

		
		// 스토리 저장
		Story s = new Story();

		s.setS_title(request.getParameter("s_title"));
		s.setS_content(request.getParameter("s_content"));
		s.setArea_num(Integer.parseInt(request.getParameter("area_num")));

		storyService.register(s);

		// 방금 저장된 스토리의 s_num값 가져오기 
		Story nowStory = storyService.findNum(request.getParameter("s_title"));
		
		
		redirectAttr.addFlashAttribute("nowStory", nowStory);
		
		return "redirect:/storymake/manage";
	}

	@RequestMapping(value = "/manage")
	public String manage(Model model) {

		try {
			model.addAttribute("cultureList", service.getCultures());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "/story/storyManage";
	}
	
	@RequestMapping(value="/manage_save", method = RequestMethod.POST)
	@ResponseBody
	public String manage_save(HttpServletRequest request, Question q, Hint h, Story s, Culture c) {
		
		
		//storageService.store(uploadfile);	
		
		questionService.register(q);
		
		Question question = questionService.findNum(q.getQ_content());
		
		h.setH_file("없음");
		h.setQ_num(question.getQ_num());
		
		hintService.register(h);
		
		Story_only so = new Story_only();
		
		so.setS_num(s.getS_num());
		
		Culture culture = service.findNum(c.getC_name());
		so.setC_num(culture.getC_num()); // 이거 해결하기
		
		
		so.setQ_num(question.getQ_num());
		so.setS_order(q.getQ_num()); // 이거 해결하기
		
		soService.register(so);
		
		return null;
	}
	
	
	 @RequestMapping(value="/otherSave", method = RequestMethod.POST)
	 @ResponseBody 
	 public String otherSave(HttpServletRequest request, Question q, Story s, Culture c) {
	 
		 	questionService.register(q);
			
			Question question = questionService.findNum(q.getQ_content());
			
			System.out.println("등록된 문제 번호 : " + question.getQ_num());
			
			Hint h = new Hint();
			h.setH_num(0);
			h.setH_content("없음");
			h.setH_file(fileName);
			h.setQ_num(question.getQ_num());
			
			System.out.println("힌트 내용 : " + h.getH_content());
			System.out.println("힌트 파일 이름 : " + h.getH_file());
			System.out.println(h.getQ_num());
			
			hintService.register(h);
			
			Story_only so = new Story_only();
			
			System.out.println("등록된 스토리 번호 : " + s.getS_num());
			
			so.setS_num(s.getS_num());
			
			Culture culture = service.findNum(c.getC_name());
			so.setC_num(culture.getC_num()); // 이거 해결하기
			
			
			so.setQ_num(question.getQ_num());
			so.setS_order(q.getQ_num()); // 이거 해결하기
			
			soService.register(so);
		 
			System.out.println("등록 완료");
			
			return null;
	 }
	 
	
	@RequestMapping(value="/fileSave", method = RequestMethod.POST)
	@ResponseBody
	public String fileSave(HttpServletRequest request, @RequestParam("file") MultipartFile file, Question q, Hint h, Story s, Culture c) { //
		
			storageService.store(file);
			fileName = file.getOriginalFilename();
			System.out.println(fileName);
		
		return null;
	}
	
//	@RequestMapping(value = "/aaa") //produces = "application/json;charset=utf-8")
//	public @ResponseBody JSONObject json() throws Exception {
//		
//		JSONObject jsonMain = new JSONObject();	// json 객체
//		
//		List<Story> items = storyService.getStorys();
//		JSONArray jArray = new JSONArray(); // json배열
//		
//		for(int i=0; i<items.size(); i++) {
//			Story s = items.get(i);
//			JSONObject row = new JSONObject();
//			
//			row.put("s_num", s.getS_num());
//			row.put("s_title", s.getS_title());
//			row.put("s_content", s.getS_content());
//			row.put("area_num", s.getArea_num());
//			
//			jArray.add(i, row);
//		}
//		// json객체에 배열을 넣음
//		jsonMain.put("sendData", jArray);
//		return jsonMain;
//	}
	
	   @RequestMapping(value = "/bbb")
	   // 주소변경예정 @RequestMapping(value = "/android/recordInsert")
	   @ResponseBody
	   public List<app_story> getStorys(HttpServletRequest request) throws Exception {
		/*
		 * // 안드로이드에게 전달하는 데이터 Map<String, String> result = new HashMap<String,
		 * String>();
		 * 
		 * result.put("data1", request.getParameter("rr_rider"));
		 * 
		 * List<Story> items = storyService.getStorys();
		 * 
		 * System.out.println(items.size());
		 * 
		 * for(int i=0; i<items.size(); i++) {
		 * 
		 * Story s = items.get(i);
		 * 
		 * result.put("s_num", String.valueOf(s.getS_num())); result.put("s_title",
		 * s.getS_title()); result.put("s_content", s.getS_content());
		 * result.put("area_num", String.valueOf(s.getArea_num()));
		 * 
		 * }
		 * 
		 * ArrayList<app_story> a = appService.getStorys();
		 * 
		 * for (app_story app_story : a) { System.out.println(app_story.getArea_name());
		 * }
		 */

	      return appService.getStorys();
	   }
	   
	   @RequestMapping(value = "storyStart")
	   @ResponseBody
	   public List<app_storyStart> getStory_only(HttpServletRequest request) throws Exception {
		   System.out.println("앱에서 받아온 스토리 값 : " + request.getParameter("s_num"));
		   
		   ArrayList<app_storyStart> list = appStartService.getNeedPHF(request.getParameter("s_num"));
		   
		   for (app_storyStart a : list) {
			   System.out.println(a.getC_name());
		   }
		   
		   return list;
	   }
}
