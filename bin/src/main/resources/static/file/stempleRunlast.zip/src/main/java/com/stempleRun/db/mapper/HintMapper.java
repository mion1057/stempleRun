package com.stempleRun.db.mapper;

import com.stempleRun.db.dto.Hint;

public interface HintMapper {

	public void insert(Hint h);
	
}
