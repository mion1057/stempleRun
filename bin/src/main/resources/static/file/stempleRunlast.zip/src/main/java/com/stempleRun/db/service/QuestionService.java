package com.stempleRun.db.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stempleRun.db.dto.Question;
import com.stempleRun.db.mapper.QuestionMapper;

@Service
public class QuestionService {

	@Autowired
	QuestionMapper questionMapper;
	
	public void register(Question q) {
		questionMapper.insert(q);
	}
	
	public Question findNum(String q_content) {
		return questionMapper.findNum(q_content);
	}
	
}
