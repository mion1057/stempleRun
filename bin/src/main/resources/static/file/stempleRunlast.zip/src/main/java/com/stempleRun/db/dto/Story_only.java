package com.stempleRun.db.dto;

public class Story_only {

	private int s_num;
	private int c_num;
	private int q_num;
	private int s_order;
	
	public int getS_num() {
		return s_num;
	}
	public void setS_num(int s_num) {
		this.s_num = s_num;
	}
	public int getC_num() {
		return c_num;
	}
	public void setC_num(int c_num) {
		this.c_num = c_num;
	}
	public int getQ_num() {
		return q_num;
	}
	public void setQ_num(int q_num) {
		this.q_num = q_num;
	}
	public int getS_order() {
		return s_order;
	}
	public void setS_order(int s_order) {
		this.s_order = s_order;
	}
}
