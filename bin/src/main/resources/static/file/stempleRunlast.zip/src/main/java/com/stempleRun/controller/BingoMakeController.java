package com.stempleRun.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.stempleRun.db.dto.BingoVO;
import com.stempleRun.db.dto.Bingo_onlyVO;
import com.stempleRun.db.dto.Culture;
import com.stempleRun.db.dto.Hint;
import com.stempleRun.db.dto.Question;
import com.stempleRun.db.dto.Story;
import com.stempleRun.db.service.AreaService;
import com.stempleRun.db.service.BingoService;
import com.stempleRun.db.service.Bingo_CallService;
import com.stempleRun.db.service.Bingo_onlyService;
import com.stempleRun.db.service.CultureService;
import com.stempleRun.db.service.StoryService;

@Controller
@RequestMapping("/bingo")
public class BingoMakeController {
	@Autowired
	AreaService areaService;
	
	@Autowired
	CultureService service;
	
	@Autowired
	BingoService bingoService;
	
	@Autowired
	Bingo_onlyService boService;
	
	@Autowired
	Bingo_CallService bingo_callservice;
	
	//빙고 수정
	@RequestMapping(value = "bingocalldetail/{b_num}")
	public String bingocalldetail(HttpServletRequest request, RedirectAttributes redirectAttr, @PathVariable int b_num, Model model) throws Exception {	
		BingoVO b = new BingoVO();
		
			model.addAttribute("bingocalldetail",boService.bingocalldetailselect(b_num));
			model.addAttribute("cultureList", service.getCultures());
			model.addAttribute("nowBingo", bingoService.findBingoTitle(b_num));
			model.addAttribute("bingocultureList", service.bingogetCultures(b_num));


//			   for (int i = 0; i < list.size(); i++) {
//			         list.get(i).setPic_file(postService.pictureDetail(list.get(i).getP_num()));
//			      }
//			String a = service.bingogetCultures(b_num);
//			System.out.println(c_name);
		return "/bingo/bingocalldetail";
	}

	//빙고 불러오기 리스트	
	@RequestMapping(value = "/bingocall")
	public String call(Model model) {
		model.addAttribute("bingo",bingo_callservice.getbingoList());
		
		return "/bingo/bingocall";
	}
	
	//빙고 생성 (큰틀)
	@RequestMapping(value = "/bingoadd")
	public String register(Model model) {

		try {

			model.addAttribute("areaList", areaService.getAreas());

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "/bingo/bingoadd";
	}
	
	//빙고 저장 (큰틀)
	@RequestMapping(value = "/bingosave", method = RequestMethod.POST)
	public String save(HttpServletRequest request, RedirectAttributes redirectAttr, Model model) throws Exception {

		model.addAttribute("cultureList", service.getCultures());

		
		// 빙고 저장
		BingoVO b = new BingoVO();

		b.setB_title(request.getParameter("b_title"));
		b.setB_content(request.getParameter("b_content"));
		b.setArea_num(Integer.parseInt(request.getParameter("area_num")));

		bingoService.register(b);
		
		BingoVO nowBingo = bingoService.findBingoNum(request.getParameter("b_title"));
		
		System.out.println(nowBingo.getB_num());
		System.out.println(nowBingo.getB_title());
		System.out.println(nowBingo.getB_content());
		
		redirectAttr.addFlashAttribute("nowBingo", nowBingo);
		
		return "redirect:/bingo/manage"; 
	}
	
	//빙고 관리페이지로 이동
	@RequestMapping(value = "/manage")
	public String manage(Model model) {

		try {
			model.addAttribute("cultureList", service.getCultures());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "/bingo/bingomanage";
	}
	
	@RequestMapping(value="/manage_save", method = RequestMethod.POST)
	@ResponseBody
	public String manage_save(HttpServletRequest request, BingoVO b, Culture c) {
		
		
		Bingo_onlyVO bo = new Bingo_onlyVO();
		
		bo.setB_num(b.getB_num());
		
		Culture culture = service.findNum(c.getC_name());
		bo.setC_num(culture.getC_num()); 
		
		boService.register(bo);
		System.out.println(bo);
		return null;
	}
	
	
	 @RequestMapping(value="/otherSave", method = RequestMethod.POST)
	 @ResponseBody 
	 public String otherSave(HttpServletRequest request, BingoVO b, Culture c, @RequestParam(value="list[]") List<String> list) {
	 
		 	int a = b.getB_num();
		 	int count = 1;

		 	for(String list2 : list) {
				Bingo_onlyVO bo = new Bingo_onlyVO();
				bo.setB_num(a);
				Culture culture = service.findNum(list2);
				bo.setC_num(culture.getC_num());
				bo.setB_order(count);
				count = count+1;
				boService.register(bo);
	        }
			return null;
	 }
}
