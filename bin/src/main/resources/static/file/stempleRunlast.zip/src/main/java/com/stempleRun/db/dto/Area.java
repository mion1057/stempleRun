package com.stempleRun.db.dto;

public class Area {

	private int area_num;
	private String area_name;
	
	
	public int getArea_num() {
		return area_num;
	}
	
	public void setArea_num(int area_num) {
		this.area_num = area_num;
	}
	
	public String getArea_name() {
		return area_name;
	}
	
	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}
}
