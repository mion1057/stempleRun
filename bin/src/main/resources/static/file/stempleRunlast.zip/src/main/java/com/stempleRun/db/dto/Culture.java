package com.stempleRun.db.dto;

public class Culture {

	private int c_num;
	private String c_name;
	private String c_latitude;
	private String c_longitude;
	private String c_file;
	private int m_num;
	private int g_code;
	
	
	public int getC_num() {
		return c_num;
	}
	
	public void setC_num(int c_num) {
		this.c_num = c_num;
	}
	
	public String getC_name() {
		return c_name;
	}
	
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	
	public String getC_latitude() {
		return c_latitude;
	}
	
	public void setC_latitude(String c_latitude) {
		this.c_latitude = c_latitude;
	}
	
	public String getC_longitude() {
		return c_longitude;
	}
	
	public void setC_longitude(String c_longitude) {
		this.c_longitude = c_longitude;
	}
	
	public String getC_file() {
		return c_file;
	}
	
	public void setC_file(String c_file) {
		this.c_file = c_file;
	}
	
	public int getM_num() {
		return m_num;
	}
	
	public void setM_num(int m_num) {
		this.m_num = m_num;
	}
	
	public int getG_code() {
		return g_code;
	}
	
	public void setG_code(int g_code) {
		this.g_code = g_code;
	}
}
