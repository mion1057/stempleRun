package com.stempleRun.db.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stempleRun.db.dto.Hint;
import com.stempleRun.db.mapper.HintMapper;

@Service
public class HintService {

	@Autowired
	HintMapper hintMapper;
	
	public void register(Hint h) {
		hintMapper.insert(h);
	}
	
}
