package com.stempleRun.db.mapper;

import java.util.ArrayList;

import com.stempleRun.db.dto.Area;

public interface AreaMapper {

	public ArrayList<Area> getAreas() throws Exception;
	
}
