package com.stempleRun.db.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stempleRun.db.dto.ReviewBoardVO;
import com.stempleRun.db.mapper.ReviewBoardMapper;

@Service
public class ReviewBoard {
	@Autowired
	ReviewBoardMapper reviewboardMapper;
	
	public ArrayList<ReviewBoardVO> getList() throws Exception{
		return reviewboardMapper.getList();
	}
	
	public ReviewBoardVO reviewboardDetail(int bno) throws Exception{
		return reviewboardMapper.reviewboardDetail(bno);
	}
	
	public int reviewboardInsert(ReviewBoardVO reviewboard) throws Exception{
		return reviewboardMapper.reviewboardInsert(reviewboard);
	}
	
	public int reviewboardUpdate(ReviewBoardVO reviewboard) throws Exception{
		return reviewboardMapper.reviewboardUpdate(reviewboard);
	}
	
	public int reviewboardDelete(int bno) throws Exception{
		return reviewboardMapper.reviewboardDelete(bno);
	}
}
