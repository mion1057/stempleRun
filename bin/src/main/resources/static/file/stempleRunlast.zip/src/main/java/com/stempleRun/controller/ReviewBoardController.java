package com.stempleRun.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.stempleRun.db.dto.ReviewBoardVO;
import com.stempleRun.db.service.ReviewBoard;

@Controller
@RequestMapping("/review")
public class ReviewBoardController {
	
	@Autowired
	ReviewBoard reviewBoard;
	
	@RequestMapping(value= {"","/"})
	public String getList(Model model) throws Exception{
		try {
			model.addAttribute("a",reviewBoard.getList());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/reviewboard/review";
	}
	
	@RequestMapping("reviewboarddetail/{bno}")
	private String reviewboardDetail(@PathVariable int bno, Model model) throws Exception{
		try {
			model.addAttribute("reviewboarddetail",reviewBoard.reviewboardDetail(bno));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/reviewboard/reviewboarddetail";
	}
	
	@RequestMapping("reviewboardinsert") //게시글 작성 폼 호출
	private String reviewboardInsert() {
		return "/reviewboard/reviewboardinsert";
	}
	
    @RequestMapping(value="/insertProc", method=RequestMethod.POST) //게시글 작성 폼 호출 예외? 이해가필요함
    private String boardInsertProc(HttpServletRequest request) throws Exception{

        ReviewBoardVO reviewboard = new ReviewBoardVO();
        reviewboard.setBno(Integer.parseInt(request.getParameter("bno")));  
        reviewboard.setTitle(request.getParameter("title"));
        reviewboard.setType(request.getParameter("type"));
        reviewboard.setWriter(request.getParameter("writer"));
        
        reviewBoard.reviewboardInsert(reviewboard);
        
        return "redirect:/review";
    }
    
	@RequestMapping("reviewboardupdate/{bno}") //게시글 수정 폼 호출
	private String reviewboardUpdate(@PathVariable int bno, Model model) throws Exception{
		try {
			model.addAttribute("reviewboardupdate",reviewBoard.reviewboardDetail(bno));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/reviewboard/reviewboardupdate";
	}
	
    @RequestMapping(value="/updateProc", method=RequestMethod.POST) //게시글 수정 폼 호출 예외? 이해가필요함
    private String boardUpdateProc(HttpServletRequest request) throws Exception{
        
        ReviewBoardVO reviewboard = new ReviewBoardVO();
        reviewboard.setBno(Integer.parseInt(request.getParameter("bno")));  
        reviewboard.setTitle(request.getParameter("title"));
        reviewboard.setType(request.getParameter("type"));
        reviewboard.setWriter(request.getParameter("writer"));
        reviewBoard.reviewboardUpdate(reviewboard);
        
        return "redirect:/review/reviewboarddetail/"+request.getParameter("bno");
    }
	
    
    
    @RequestMapping("reviewboarddelete/{bno}")
    private String reviewboardDelete(@PathVariable int bno) throws Exception{
        
        ReviewBoardVO reviewboard = new ReviewBoardVO();
    	reviewBoard.reviewboardDelete(bno);
        
        return "redirect:/review";
    }
}
