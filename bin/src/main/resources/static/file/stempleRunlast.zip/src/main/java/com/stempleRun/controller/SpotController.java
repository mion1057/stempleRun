package com.stempleRun.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.stempleRun.db.dto.Picture;
import com.stempleRun.db.dto.PostVO;
import com.stempleRun.db.service.CultureService;
import com.stempleRun.db.service.MemberService;
import com.stempleRun.db.service.PostService;
import com.stempleRun.db.service.SpotService;



@Controller
@RequestMapping("/hotspot")
public class SpotController {
	
	@Autowired
	private MemberService service;
	
	@Autowired
	private PostService services;
	
	@Autowired
	private SpotService spotService;
	
	@RequestMapping(value = "/mypage")
	public String postList(Model model) {
		try {
			model.addAttribute("memberList", service.getMembers());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "/hotspot/mypage";
	}
	
	@GetMapping(value="/test")
	@ResponseBody
	public ArrayList<Picture> getMap(){
		return spotService.getPictures();	
	}
	
	
	@RequestMapping(value="/hotspot_locate")
	public String LocateHotspot(Model model) {
		try {
			model.addAttribute("postList", services.getList());
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "/hotspot/hotspot_locate";
	}
	
	@RequestMapping(value="/hotspot_main/day")
	public String RDayRank(Model model) throws Exception {
		model.addAttribute("postList", services.getDayRank());
		return "/hotspot/hotspot_main";
	}
	
	@RequestMapping(value="/hotspot_main/week")
	public String RweekRank(Model model) throws Exception {
		model.addAttribute("postList", services.getWeekRank());
		return "/hotspot/hotspot_main";
	}
	
	@RequestMapping("/hotspot_main/month")
	public String RMonthRank(Model model) throws Exception {
		model.addAttribute("postList", services.getMonthRank());
		return "hotspot/hotspot_main";
	}
	@RequestMapping(value="/hotspot_main")
	public String MainHotspot(Model model) {
		
		try {
			model.addAttribute("postList", services.getList());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "/hotspot/hotspot_main";
	}
	@GetMapping(value="/hotspot_locate")
	public String SearchHotspot(@RequestParam(value="keyword") String keyword, Model model) throws Exception {
		
		 model.addAttribute("postList", spotService.getSearchList(keyword));
	
		return "/hotspot/hotspot_locate";
	} 


}
