package com.stempleRun.controller;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.stempleRun.db.dto.PictureVO;
import com.stempleRun.db.dto.PostVO;
import com.stempleRun.db.service.MemberService;
import com.stempleRun.db.service.PostService;

@Controller
@RequestMapping("/gallery")
public class PostController {

	@Autowired
	private PostService postService;

	@Autowired
	private MemberService memberSerivce;

	// 목록
	@RequestMapping("/list")
	public String getList(Model model) throws Exception {
		ArrayList<PostVO> list = postService.getList();

		for (PostVO a : list) {
			String c = memberSerivce.getM_name(a.getM_num());
			a.setM_name(c);
		}

		for (int i = 0; i < list.size(); i++) {
			list.get(i).setPic_file(postService.pictureDetail(list.get(i).getP_num()));
		}
		model.addAttribute("list", list);
		return "gallery/list";
	}

	// 인기순
	@RequestMapping("/list/popular")
	public String getPopular(Model model) throws Exception {
		ArrayList<PostVO> list = postService.getPopular();
		for (PostVO a : list) {
			String c = memberSerivce.getM_name(a.getM_num());
			a.setM_name(c);
		}
		for (int i = 0; i < list.size(); i++) {
			list.get(i).setPic_file(postService.pictureDetail(list.get(i).getP_num()));
		}
		model.addAttribute("list", list);

		return "gallery/list";
	}

	// 최신순
	@RequestMapping("/list/lately")
	public String getLately(Model model) throws Exception {
		ArrayList<PostVO> list = postService.getLately();
		for (PostVO a : list) {
			String c = memberSerivce.getM_name(a.getM_num());
			a.setM_name(c);
		}
		for (int i = 0; i < list.size(); i++) {
			list.get(i).setPic_file(postService.pictureDetail(list.get(i).getP_num()));
		}
		model.addAttribute("list", list);
		return "gallery/list";
	}

	// 일간
	@RequestMapping("/ranking/day")
	public String getDayRank1(Model model) throws Exception {
		ArrayList<PostVO> posts = postService.getDayRank();
		for (PostVO a : posts) {
			String c = memberSerivce.getM_name(a.getM_num());
			a.setM_name(c);
		}
		for (int i = 0; i < posts.size(); i++) {
			posts.get(i).setPic_file(postService.pictureDetail(posts.get(i).getP_num()));
		}
		model.addAttribute("posts", posts);
		return "gallery/ranking";
	}

	// 주간
	@RequestMapping("/ranking/week")
	public String getWeekRank(Model model) throws Exception {
		ArrayList<PostVO> posts = postService.getWeekRank();
		for (PostVO a : posts) {
			String c = memberSerivce.getM_name(a.getM_num());
			a.setM_name(c);
		}
		for (int i = 0; i < posts.size(); i++) {
			posts.get(i).setPic_file(postService.pictureDetail(posts.get(i).getP_num()));
		}
		model.addAttribute("posts", posts);
		return "gallery/ranking";
	}

	// 월간
	@RequestMapping("/ranking/month")
	public String getMonthRank(Model model) throws Exception {
		ArrayList<PostVO> posts = postService.getMonthRank();
		for (PostVO a : posts) {
			String c = memberSerivce.getM_name(a.getM_num());
			a.setM_name(c);
		}
		for (int i = 0; i < posts.size(); i++) {
			posts.get(i).setPic_file(postService.pictureDetail(posts.get(i).getP_num()));
		}
		model.addAttribute("posts", posts);
		return "gallery/ranking";
	}

	// 게시글 작성
	@RequestMapping("/insert/{pic_num}" )
	private String postInsert(@PathVariable int pic_num, Model model) throws Exception {
		model.addAttribute("picture", postService.getPicture(pic_num));
		return "gallery/insert";
	}

	@RequestMapping(value = "/insertProc", method = RequestMethod.POST)
	private String postInsertProc(int pic_num, HttpServletRequest request) throws Exception {

		PostVO post = new PostVO();
		PictureVO picture = new PictureVO();
		Date ldt = new Date();
 
		post.setP_title(request.getParameter("title"));
		post.setP_content(request.getParameter("content"));
		post.setP_day(ldt);
		post.setM_num(Integer.parseInt(request.getParameter("m_num")));
		post.setPic_num(Integer.parseInt(request.getParameter("pic_num")));
		
		picture.setPic_num(pic_num);
		picture.setPic_latitude(request.getParameter("pic_latitude"));
		picture.setPic_longitude(request.getParameter("pic_longitude"));
		
		postService.locationUpdate(picture);
		postService.postInsert(post);

		return "redirect:/gallery/list";
	}

	// 게시글 상세
	@RequestMapping("/detail/{p_num}")
	private String postDetail(@PathVariable int p_num, Model model) throws Exception {
		model.addAttribute("detail", postService.postDetail(p_num));
		model.addAttribute("writer", postService.postWriter(p_num));
		String name;
		name = postService.pictureDetail(p_num);
		model.addAttribute("picture", name);

		return "gallery/detail";
	}

	@RequestMapping("/locationDetail/{p_num}")
	@ResponseBody
	private PictureVO locationDetail(@PathVariable int p_num) throws Exception {
		return postService.locationDetail(p_num);
	}

	@RequestMapping("/detail/map/{p_num}")
	private String mapDetail(@PathVariable int p_num, Model model) throws Exception {
		model.addAttribute("p_num", p_num);
		return "gallery/map";
	}

	// 게시글 삭제
	@RequestMapping("/delete/{p_num}")
	private String postDelete(@PathVariable int p_num) throws Exception {
		postService.postDelete(p_num);
		return "redirect:/gallery/list";
	}

	// 게시글 추천
	@RequestMapping("/recommendProc/{p_num}/{url}")
	private String getRecommend(@PathVariable int p_num, Model model, @PathVariable String url) throws Exception {
		model.addAttribute("recommend", postService.getRecommend(p_num));

		return "redirect:/gallery/ranking/" + url;
	}

	// 게시글 수정
	@RequestMapping("/update/{p_num}")
	private String postUpdate(@PathVariable int p_num, PictureVO picture, Model model) throws Exception {
		model.addAttribute("update", postService.postDetail(p_num));
		model.addAttribute("pic_num", postService.getPicnum(p_num));
		model.addAttribute("pic_tag", postService.getPictag(p_num));
		model.addAttribute("pic_latitude", postService.getLatitude(p_num));
		model.addAttribute("pic_longitude", postService.getLongitude(p_num));
		
		String name;
		name = postService.pictureDetail(p_num);
		name = name;
		model.addAttribute("picture", name);
		
		return "gallery/update";
	}

	@RequestMapping(value = "/updateProc", method = RequestMethod.POST)
	private String postUpdateProc(PostVO post, PictureVO picture, HttpServletRequest request, Model model)
			throws Exception {

		post.setP_title(request.getParameter("p_title"));
		post.setP_content(request.getParameter("p_content"));
		post.setP_num(Integer.parseInt(request.getParameter("p_num")));

		picture.setPic_latitude(request.getParameter("p_latitude"));
		picture.setPic_longitude(request.getParameter("p_longitude"));
		picture.setPic_num(Integer.parseInt(request.getParameter("pic_num")));
		picture.setPic_tag(request.getParameter("pic_tag"));
		
		postService.pictagUpdate(picture);
		postService.locationUpdate(picture);
		postService.postUpdate(post);

		return "redirect:/gallery/detail/" + request.getParameter("p_num");
	}

	@RequestMapping("/test")
	private String Test() throws Exception {
		return "gallery/test";
	}
}