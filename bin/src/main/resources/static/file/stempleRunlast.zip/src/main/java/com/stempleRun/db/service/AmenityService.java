package com.stempleRun.db.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stempleRun.db.dto.Amenity;
import com.stempleRun.db.mapper.AmenityMapper;

@Service
public class AmenityService {

	@Autowired
	AmenityMapper amenityMapper;
	
	public void register(Amenity a) {
		
	}
	
}
