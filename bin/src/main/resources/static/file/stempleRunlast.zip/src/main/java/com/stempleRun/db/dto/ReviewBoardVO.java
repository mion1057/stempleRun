package com.stempleRun.db.dto;

public class ReviewBoardVO {
	private int bno;
	private String title;
	private String type;
	private String writer;
	private int nal;
	private int chu;
	
	//게시글 번호
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	
	//게시글 제목
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	//게시글 분류
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	//게시글 작성자
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	
	//게시글 작성일자
	public int getNal() {
		return nal;
	}
	public void setNal(int nal) {
		this.nal = nal;
	}
	
	//게시글 추천수
	public int getChu() {
		return chu;
	}
	public void setChu(int chu) {
		this.chu = chu;
	}
	
}
