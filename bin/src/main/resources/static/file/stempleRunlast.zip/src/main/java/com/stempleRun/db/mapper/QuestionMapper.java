package com.stempleRun.db.mapper;

import com.stempleRun.db.dto.Question;

public interface QuestionMapper {

	public void insert(Question q);
	
	public Question findNum(String q_content);
}
