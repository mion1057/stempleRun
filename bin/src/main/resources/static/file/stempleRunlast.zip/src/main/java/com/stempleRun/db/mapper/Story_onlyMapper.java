package com.stempleRun.db.mapper;

import com.stempleRun.db.dto.Story_only;

public interface Story_onlyMapper {
	
	public void insert(Story_only so);
	
}
