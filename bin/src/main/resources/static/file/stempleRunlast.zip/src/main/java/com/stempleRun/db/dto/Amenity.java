package com.stempleRun.db.dto;

public class Amenity {
	
	private int a_num;
	private String a_name;
	private String a_latitude;
	private String a_longitude;
	
	
	public int getA_num() {
		return a_num;
	}
	public void setA_num(int a_num) {
		this.a_num = a_num;
	}
	public String getA_name() {
		return a_name;
	}
	public void setA_name(String a_name) {
		this.a_name = a_name;
	}
	public String getA_latitude() {
		return a_latitude;
	}
	public void setA_latitude(String a_latitude) {
		this.a_latitude = a_latitude;
	}
	public String getA_longitude() {
		return a_longitude;
	}
	public void setA_longitude(String a_longitude) {
		this.a_longitude = a_longitude;
	}
}
