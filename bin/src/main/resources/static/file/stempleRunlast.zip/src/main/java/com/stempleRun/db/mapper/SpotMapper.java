package com.stempleRun.db.mapper;

import java.util.ArrayList;
import java.util.Date;

import com.stempleRun.db.dto.Picture;
import com.stempleRun.db.dto.PostVO;

public interface SpotMapper {
	
	public ArrayList<PostVO> getSearchList(String keyword)throws Exception;

	public ArrayList<Picture> getPictures();

}
