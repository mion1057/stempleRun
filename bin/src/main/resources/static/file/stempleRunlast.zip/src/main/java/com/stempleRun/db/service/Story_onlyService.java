package com.stempleRun.db.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stempleRun.db.dto.Story_only;
import com.stempleRun.db.mapper.Story_onlyMapper;

@Service
public class Story_onlyService {

	@Autowired
	Story_onlyMapper mapper;
	
	public void register(Story_only so) {
		mapper.insert(so);
	}
	
}
